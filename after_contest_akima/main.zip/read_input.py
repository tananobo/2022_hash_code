from contributer import Contributer
from project import Project


input_dir = "input/a_an_example.in.txt"

def read_input(input_dir):

    with open(input_dir) as f:
        contributor_num, project_num = map(int, f.readline().split())

        contributer_dict = {}

        for i in range(contributor_num):
            name, skill_num = f.readline().split()
            contributer = Contributer(name, skill_num)

            for j in range(int(skill_num)):
                skill_name, skill_level = f.readline().split()
                contributer.owned_skill(skill_name, skill_level)
            
            contributer_dict[name] = contributer

        project_dict = {}
        
        for i in range(project_num):
            name, project_period, max_score, best_day, role_num = f.readline().split()
            project = Project(name, project_period, max_score, best_day, role_num )

            for j in range(int(role_num)):
                skill_name, skill_level = f.readline().split()
                project.required_skill(skill_name, skill_level)

            project_dict[name]  = project


    return contributer_dict, project_dict

